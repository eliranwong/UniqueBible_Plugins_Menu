import config
from gui.MultiLineInputDialog import MultiLineInputDialog

fields = [("Highlight", ['all', 'hl1', 'hl2', 'ul1']), ("Books", ['all', 'ot', 'nt'])]
dialog = MultiLineInputDialog("Search Highlights", fields)
if dialog.exec():
    data = dialog.getInputs()
    highlight = data[0].strip()
    range = data[1].strip()
    search = "SEARCHHIGHLIGHT:::{0}:::{1}".format(highlight, range)
    config.mainWindow.runTextCommand(search)
