import config

config.mainWindow.nextStudyWindowTab()