import config

config.mainWindow.nextBibleWindowTab()