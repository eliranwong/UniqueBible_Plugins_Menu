import config
from util.BibleBooks import BibleBooks

text = "KJV"
book = BibleBooks.eng[str(config.mainB)][0]
config.mainWindow.runTextCommand("BIBLE:::{0}:::{1} {2}:{3}".format(text, book, config.mainC, config.mainV))
