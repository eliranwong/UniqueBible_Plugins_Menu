import config

config.mainWindow.webtopApp("torbrowser-launcher")