import config
from qtpy.QtWidgets import QInputDialog, QLineEdit

text, ok = QInputDialog.getText(config.mainWindow, "Search for word with Strongs",
        "Search ('αρχη G746'):", QLineEdit.Normal, "")
if ok:
    words = text.split(" ")
    if len(words) == 2:
        search = "REGEXSEARCH:::\\b{0}\\b.*\\b{1}\\b".format(words[0], words[1])
        config.mainWindow.runTextCommand(search)
