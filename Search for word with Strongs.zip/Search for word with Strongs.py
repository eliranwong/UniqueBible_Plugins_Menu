import glob
import os
from pathlib import Path
import config
from gui.MultiLineInputDialog import MultiLineInputDialog

if hasattr(config, "tempSaveWordForSearch"):
    word = config.tempSaveWordForSearch
else:
    word = ""
if hasattr(config, "tempStrongsWordForSearch"):
    strongs = config.tempStrongsWordForSearch
else:
    strongs = ""
if "Strongs" in config.bibleCollections:
    bibles = config.bibleCollections["Strongs"]
else:
    bibles = [Path(os.path.basename(file)).stem for file in glob.glob(r"{0}/bibles/*.bible".format(config.marvelData))]
    bibles = sorted(bibles)
fields = [("Greek/Hebrew", word), ("Strongs", strongs), ("Bible", bibles)]
dialog = MultiLineInputDialog("Search for word with Strongs", fields)
if dialog.exec():
    data = dialog.getInputs()
    word = data[0].strip()
    strongs = data[1].strip()
    bible = data[2]
    search = None
    if len(word) > 2 and len(strongs) > 2:
        search = "REGEXSEARCH:::{0}:::\\b{1}\\b.*\\b{2}\\b".format(bible, word, strongs)
    elif len(strongs) > 2:
        search = "REGEXSEARCH:::{0}:::\\b{1}\\b".format(bible, strongs)
    if search:
        config.mainWindow.runTextCommand(search)
        config.tempSaveWordForSearch = word
        config.tempStrongsWordForSearch = strongs
