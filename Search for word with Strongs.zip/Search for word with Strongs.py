import config

from gui.MultiLineInputDialog import MultiLineInputDialog

fields = [("Greek/Hebrew", ""), ("Strongs", "")]
dialog = MultiLineInputDialog("Search for word with Strongs", fields)
if dialog.exec():
    words = dialog.getInputs()
    original = words[0].strip()
    strongs = words[1].strip()
    if len(original) > 2 and len(strongs) > 2:
        search = "REGEXSEARCH:::\\b{0}\\b.*\\b{1}\\b".format(original, strongs)
        config.mainWindow.runTextCommand(search)
