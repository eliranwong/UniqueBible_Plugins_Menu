import config

config.mainWindow.webtopApp("signal-desktop")