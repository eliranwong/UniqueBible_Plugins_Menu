import config

config.mainWindow.webtopAurApp("google-chrome-stable", "google-chrome", "https://office.com")