import config

config.mainWindow.openPdfDialog()