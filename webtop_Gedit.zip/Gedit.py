import config

config.mainWindow.webtopApp("gedit")