import config
from util.BibleVerseParser import BibleVerseParser
if config.qtLibrary == "pyside6":
    from PySide6.QtWebEngineCore import QWebEnginePage
else:
    from qtpy.QtWebEngineWidgets import QWebEnginePage

currentIndex = config.mainWindow.mainView.currentIndex()
b, c, v = config.mainWindow.getTabBcv(studyView=False, index=currentIndex)
currentText = config.mainWindow.getTabText(studyView=False, index=currentIndex)
reference = BibleVerseParser(config.parserStandarisation).bcvToVerseReference(b, c, v)

# Disable some config values temporarily
openBibleWindowContentOnNextTab = config.openBibleWindowContentOnNextTab
config.openBibleWindowContentOnNextTab = False
updateMainReferenceOnChaningTabs = config.updateMainReferenceOnChaningTabs
config.updateMainReferenceOnChaningTabs = False

for index in range(config.numberOfTab):
    # Run codes only on non-empty tab
    if config.mainWindow.mainView.tabToolTip(index).strip():
        config.mainWindow.mainView.setCurrentIndex(index)
        text = config.mainWindow.getTabText(studyView=False, index=index)
        command = "BIBLE:::{0}:::{1}".format(text, reference)
        config.mainWindow.runTextCommand(command)

# Restore config values
config.openBibleWindowContentOnNextTab = openBibleWindowContentOnNextTab
config.updateMainReferenceOnChaningTabs = updateMainReferenceOnChaningTabs

config.mainWindow.mainView.setCurrentIndex(currentIndex)

config.mainB, config.mainC, config.V = b, c, v
config.mainText = currentText
config.mainWindow.mainPage.triggerAction(QWebEnginePage.Reload)