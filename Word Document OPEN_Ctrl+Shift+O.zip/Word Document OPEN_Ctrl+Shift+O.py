import config

config.mainWindow.openDocxDialog()