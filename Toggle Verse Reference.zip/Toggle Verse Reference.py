# Requires installing the startup/toggleVerseReferency.py for this plugin to work

import config

if hasattr(config, "displayVerseReference"):
    config.displayVerseReference = not config.displayVerseReference
else:
    config.displayVerseReference = False

config.mainWindow.reloadCurrentRecord()
