"""Important Notes:
This plugin uses Google Cloud Text to Speech service.
Read more at: https://cloud.google.com/text-to-speech

To work with this plugin, you need to:
1) Create a credential key and download it.  Read for details at https://cloud.google.com/text-to-speech/docs/before-you-begin
2) Rename the credential key file to "credentials_GoogleCloudTextToSpeech.json"
3) Place the credential key file "credentials_GoogleCloudTextToSpeech.json" in UniqueBibleApp folder.

Remarks: "Google Cloud Text-to-Speech is priced based on the number of characters sent to the service to be synthesized into audio each month. 
The first 1 million characters for WaveNet voices are free each month."  1 million characters each month should be free enough for general use.
"""

# User can change bible module in the following line:
bibleModule = "NET"
languageCode = "en"
# bibleModule = "CUV"
# languageCode = "yue-HK"

from db.BiblesSqlite import Bible
# getBookList, getChapterList, readTextChapter
import os, re, config
from install.module import *


def saveGTTSAudio(bibleModule, b, c, v, verseText):
    try:
        from gtts import gTTS
        moduleInstalled = True
    except:
        moduleInstalled = False
    if not moduleInstalled:
        installmodule("--upgrade gTTS")

    moduleFolder = os.path.join(os.getcwd(), config.musicFolder, bibleModule)
    if not os.path.isdir(moduleFolder):
        os.makedirs(moduleFolder)
    audioFolder = os.path.join(moduleFolder, "{0}_{1}".format(b, c))
    if not os.path.isdir(audioFolder):
        os.makedirs(audioFolder)
    audioFilename = "{0}_{1}_{2}_{3}.mp3".format(bibleModule, b, c, v)
    outputFile = os.path.join(audioFolder, audioFilename)

    from gtts import gTTS
    tts = gTTS(verseText, lang=languageCode)
    tts.save(outputFile)

def saveCloudTTSAudio(bibleModule, b, c, v, verseText):
    try:
        from google.cloud import texttospeech
        moduleInstalled = True
    except:
        moduleInstalled = False
    if not moduleInstalled:
        installmodule("--upgrade google-cloud-texttospeech")

    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.path.join(os.getcwd(), "credentials_GoogleCloudTextToSpeech.json")

    # Modified from ource: https://cloud.google.com/text-to-speech/docs/create-audio-text-client-libraries#client-libraries-install-python
    """Synthesizes speech from the input string of text or ssml.
    Make sure to be working in a virtual environment.

    Note: ssml must be well-formed according to:
        https://www.w3.org/TR/speech-synthesis/
    """
    from google.cloud import texttospeech

    # Instantiates a client
    client = texttospeech.TextToSpeechClient()

    # Set the text input to be synthesized
    synthesis_input = texttospeech.SynthesisInput(text=verseText)

    # Build the voice request, select the language code (e.g. "yue-HK") and the ssml
    # voice gender ("neutral")
    voice = texttospeech.VoiceSelectionParams(
        language_code=languageCode, ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL
    )

    # Select the type of audio file you want returned
    audio_config = texttospeech.AudioConfig(
        audio_encoding=texttospeech.AudioEncoding.MP3
    )

    # Perform the text-to-speech request on the text input with the selected
    # voice parameters and audio file type
    response = client.synthesize_speech(
        input=synthesis_input, voice=voice, audio_config=audio_config
    )

    # The response's audio_content is binary.
    # Save into mp3
    moduleFolder = os.path.join(os.getcwd(), config.musicFolder, bibleModule)
    if not os.path.isdir(moduleFolder):
        os.makedirs(moduleFolder)
    audioFolder = os.path.join(moduleFolder, "{0}_{1}".format(b, c))
    if not os.path.isdir(audioFolder):
        os.makedirs(audioFolder)
    audioFilename = "{0}_{1}_{2}_{3}.mp3".format(bibleModule, b, c, v)
    outputFile = os.path.join(audioFolder, audioFilename)
    with open(outputFile, "wb") as out:
        # Write the response to the output file.
        out.write(response.audio_content)
        #print('Audio content written to file "{0}"'.format(outputFile))

# main process begin from below
bible = Bible(bibleModule)
# For testing
# For selected books
#for book in (66,):
# For a range of book in a row
for book in range(42, 66):
# The following two lines do all books in one go, but it is not recommended
#books = bible.getBookList()
#for book in books:
    chapters = bible.getChapterList(book)
    for chapter in chapters:
        # Change the start chapter if last process break somewhere
        if chapter >= 0:
            textChapter = bible.readTextChapter(book, chapter)
            for b, c, v, verseText in textChapter:
                verseText = re.sub("<.*?>", "", verseText)
                verseText = re.sub("[<>〔〕\[\]（）\(\)]", "", verseText)
                # For testing:
                #print(bibleModule, b, c, v, verseText)
                # User can change text-to-speech module in the following line (saveCloudTTSAudio or saveGTTSAudio):
                try:
                    saveCloudTTSAudio(bibleModule, b, c, v, verseText)
                except:
                    print("Failed to save {0}.{1}.{2}: {3}".format(b, c, v, verseText))
