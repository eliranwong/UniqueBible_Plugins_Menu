import config

config.mainWindow.webtopApp("pycharm", "pycharm-community-edition", "/config/UniqueBible/")